# Instructions

## Warnings

There is a limitation in REFPROP v.10.0 that only 40 departure functions may be present
in the HMX.BNC file. If more departure functions are present, REFPROP will be
silently corrupted and incorrect results will be returned. To work-around 
this problem, and still make the new refrigerant mixture models available
to users, other models of lesser interest to the refrigerants community must be 
removed to have fewer than 40 departure functions in the file.

To use the new files provided in the ``contents`` folder:

1. Make a copy of the entire REFPROP folder on your machine to somewhere else. It could be next to the REFPROP installation, but that requires admin access on many machines. A folder in your user's home directory is usually a better bet as you almost always have write access in that folder.
2. Change the RPPREFIX environment variable to point to this new folder. Change the entry for REFPROP on your PATH environment variable to point to this new location.
3. Take the files in the ``contents`` folder and overwrite the ones in your copy(!) of REFPROP

## Validation

Run the Python script ``check_values.py``; it does the process described above within the script and it should yield the output file contents:

```
\begin{tabular}{ccccccc}
\toprule
names (1/2) & $z_1$ / mole frac. & $T$ / K & $\rho$ / mol/m$^3$ & $T_{\rm red}$ / K & $\rho_{\rm red}$ / mol/m$^3$ & $\alpha^{\rm r}$\\
\midrule
R32 & 1.0 & 439.0 & 6520.0 & 351.2550000000000 & 8150.0845999999992 & -0.54027465374297\\
R1234YF & 1.0 & 460.0 & 3344.0 & 367.8500000000000 & 4180.0000000000000 & -0.46835370596876\\
R125 & 1.0 & 424.0 & 3823.0 & 339.1730000000000 & 4779.0000000000000 & -0.45506005234449\\
R152A & 1.0 & 483.0 & 4457.0 & 386.4110000000000 & 5571.4499999999998 & -0.50742149570150\\
R1234ZEE & 1.0 & 478.0 & 3432.0 & 382.5130000000000 & 4290.0000000000000 & -0.46340978447230\\
R227EA & 1.0 & 469.0 & 2796.0 & 374.9000000000000 & 3495.0000000000000 & -0.44238576197982\\
R32/R1234YF & 0.4 & 445.0 & 4149.0 & 355.8223718962623 & 5186.1403601482143 & -0.47311064743910\\
R32/R1234ZEE & 0.4 & 451.0 & 4242.0 & 360.5363396425610 & 5302.9894479051327 & -0.48576186760231\\
R125/R1234YF & 0.4 & 445.0 & 3513.0 & 355.9041714483963 & 4391.8742755801013 & -0.46576307479447\\
R1234YF/R152A & 0.4 & 469.0 & 3930.0 & 374.8173271996728 & 4912.7184190598955 & -0.48967548916638\\
R1234ZEE/R227EA & 0.4 & 470.0 & 3023.0 & 376.0139530327517 & 3778.4584946374857 & -0.45378834770736\\

\bottomrule
\end{tabular}
```

## Context

There are 48 departure functions in the development HMX.BNC, but REFPROP version 10.0
only supports 40 departure functions, so in order to allow the HMX.BNC to be used
with REFPROP version 10.0 (the only released version of REFPROP 10.x available),
a number of departure functions must be disabled, in this case by moving the departure 
functions below the line that reads: @END

These models were disabled as they are not of great interest to the refigerants community.

KWL  Richardson et al. model for the helium-hydrogen mixture
B03  Tkaczuk et al. (2020) model for helium + neon
B04  Tkaczuk et al. (2020) model for helium + argon
B05  Tkaczuk et al. (2020) model for neon + argon
BCC  Souza and Herrig model for the CO2-CO mixture
BHA  Neumann model for the hydrogen-ammonia mixture
BMH  methane/hydrogen mixture
BNH  Nitrogen/Hydrogen
BXH  CO/Hydrogen
BCH  CO2/hydrogen mixture
BMW  Monoethanolamine/Water mixture
BDW  Diethanolamine/Water mixture

## Help!

Please open an issue here: https://github.com/usnistgov/REFPROP-issues/issues/new and fill out the entire template. Or email ian.bell@nist.gov if github is blocked by your employer.