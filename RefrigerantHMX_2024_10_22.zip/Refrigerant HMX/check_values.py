import itertools
import os
import shutil

import pandas
import numpy as np

import ctREFPROP.ctREFPROP as ct

os.environ['RPPREFIX'] = os.getenv('HOME') + '/REFPROP10'
if not os.path.exists(os.getenv('RPPREFIX')):
    raise ValueError("You will need to change the path above this line in the script to the location of your REFPROP base installation")

# Copy files into a temporary folder
shutil.copytree(os.getenv('RPPREFIX')+'/FLUIDS', 'FLUIDS', dirs_exist_ok=True)
shutil.copy2('contents/HMX.BNC', 'FLUIDS')
shutil.copy2('contents/R1234YF.FLD', 'FLUIDS')
shutil.copy2('contents/R152A.FLD', 'FLUIDS')
shutil.copy2('contents/R1336MZZE.FLD', 'FLUIDS')

here = os.path.dirname(__file__)
RP = ct.REFPROPFunctionLibrary(os.getenv('RPPREFIX'))
RP.SETPATHdll(here)

header = r'''\begin{tabular}{ccccccc}
\toprule
'''

footer = r'''
\bottomrule
\end{tabular}
'''

def check_value_table():
    # Start off with nice round values of tau and delta
    tau = 0.8
    delta = 0.8

    pures = [['R32'],['R1234YF'],['R125'],['R152A'],['R1234ZEE'],['R227EA']]
    pairs = [        
        ['R32','R1234YF'],['R32','R1234ZEE'],['R125','R1234YF'],['R1234YF','R152A'],['R1234ZEE','R227EA']
    ]

    def one_REFPROP(pair, molefrac):
        hFld = '*'.join(pair)
        r = RP.SETUPdll(len(molefrac), hFld, 'HMX.BNC', 'DEF')
        if r.ierr != 0:
            print(r.herr)
            quit()
        r = RP.REFPROPdll("","","TRED;DRED",RP.MOLAR_BASE_SI,0,0,0,0,molefrac)
        assert(r.ierr == 0)
        Tr, rhor = r.Output[0:2]
        T = round(Tr/tau, 0) # K
        rho = round(delta*rhor, 0) # mol/m^3
        alphar = RP.REFPROPdll("","TD&","PHIR00",RP.MOLAR_BASE_SI,0,0,T,rho,molefrac).Output[0]
        return {'names (1/2)': pair, '$z_1$ / mole frac.':molefrac[0], '$T$ / K':T, r'$\rho$ / mol/m$^3$': rho, r'$T_{\rm red}$ / K': Tr, 
                r'$\rho_{\rm red}$ / mol/m$^3$': rhor, r'$\alpha^{\rm r}$': alphar}

    # The pure components
    o = []
    for pair, molefrac in zip(pures, itertools.cycle([[1.0]])):
        R = one_REFPROP(pair, molefrac)  # ; print(R)
        o.append(R)
        print(o[-1])

    # The mixture data points
    for pair, molefrac in zip(pairs, itertools.cycle([np.array([0.4, 0.6])])):
        print(pair, molefrac)
        R = one_REFPROP(pair, molefrac)  #; print(R)
        o.append(R)
    # print(o)

    df = pandas.DataFrame(o)
    fmts = {'names (1/2)': '{0:s}', '$z_1$ / mole frac.': '{0:0.1f}', 
        '$T$ / K': '{0:0.1f}', r'$\rho$ / mol/m$^3$':'{0:0.1f}', 
        r'$T_{\rm red}$ / K': '{0:17.13f}', r'$\rho_{\rm red}$ / mol/m$^3$': '{0:17.13f}', 
        r'$\alpha^{\rm r}$': '{0:17.14f}'
    }
    o = header + ' & '.join(fmts.keys()) + '\\\\\n'+r'\midrule'+'\n'

    for ir, row in df.iterrows():
        rowblock = []
        for k, v in fmts.items():
            if k == 'names (1/2)':
                val = '/'.join(row[k])
            else:
                val = row[k]
            rowblock.append(v.format(val))
        o += ' & '.join(rowblock) + '\\\\\n'
    o += footer
    print(here+'/check_values.tex.in')
    with open(here+'/check_values.tex.in','w') as fp:
        fp.write(o)

if __name__ == '__main__':
    try:
        check_value_table()
    finally:
        shutil.rmtree('FLUIDS')